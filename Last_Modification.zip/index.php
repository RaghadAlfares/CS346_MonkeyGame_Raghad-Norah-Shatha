<?php 
session_start();

	include("Server.php");
	include("functions.php");


?>
<!DOCTYPE html>
<html lang="en" >
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="style.css" />
    <title>T-Rex Runner</title>
  </head>
  <body>
    
    <a href="logout.php" id="Logout">Logout</a>
      <div class="intro">Press space for start</div>

        <img src="trex.png" alt="T-Rex" class="trex" />
        <img src="cactus.png" alt="cactus" class="obstacle" />
        <div ><h2>Score:<span class="score"></span></h2>
        <h2 id="highest">Highest Score:<span class="Hscore"></span></h2>
        </div>
    <script src="script.js"></script> 
    
   <?php 
   echo"<p><table><tr><th>Rank</th><th>Name</th><th>Score</th></tr>";
   
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_name, score FROM users ORDER BY score DESC";
    $result = mysqli_query($con,$sql);
    $rank = 1;
    $count = mysqli_num_rows($result);
    if (mysqli_num_rows($result)){
      
      while ($row = mysqli_fetch_assoc($result)){
        Echo"<tr>

        <td>{$rank}</td>
        
        <td>{$row['user_name']}</td>
        
        <td>{$row['score']}</td>
        
        </tr>";
        
        $rank++;
   }
   Echo" </table></p>";
 } 
    
    if(isset($_GET['score'])) {
  $Ascore = $_GET['score'];

      //here we do update score
$chscore = "SELECT score FROM users WHERE user_id = '$user_id'";
$resultt = mysqli_query($con,$chscore);
while ($row = mysqli_fetch_assoc($resultt)){
  if($Ascore > $row['score']){
  $sql = "UPDATE users SET score = '$Ascore' WHERE user_id= '$user_id'";
  if(!(mysqli_query($con, $sql))){
   echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
} 
  }
}


}
   ?>
  

     
  </body>
</html>